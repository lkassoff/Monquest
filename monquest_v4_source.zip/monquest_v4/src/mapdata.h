#ifndef MAPDATA_H
#define MAPDATA_H
#include <gb/gb.h>
extern const unsigned char map_meadow[];
extern const unsigned char map_cave[];
extern const unsigned char map_hut[];
#endif
