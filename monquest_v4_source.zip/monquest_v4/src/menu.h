#ifndef MENU_H
#define MENU_H
void menu_open(void);
void menu_show_save(void);
void menu_show_party(void);
#endif
