#ifndef SFX_H
#define SFX_H
#include <gb/gb.h>
void sfx_hit(void);
void sfx_capture(void);
#endif
