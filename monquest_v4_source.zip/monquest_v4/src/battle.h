#ifndef BATTLE_H
#define BATTLE_H
#include "creatures.h"
void battle_start(UINT8 area); // area: 0 meadow, 1 cave
#endif
